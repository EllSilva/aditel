const nodemailer = require("nodemailer");
const express = require("express");
const bodyParser = require("body-parser");

const app = express();
const port = 3000

app.use(bodyParser.urlencoded({ extended: false }))

app.use(bodyParser.json())

app.get('/', (req, res) => { res.send('heelo kim Worde') })

const SMTP_CONFIG = require("./config/smtp");


app.post('/sedmail', async (req, res) => {

  const {
    nome,
    email,
    assunto,
    telef,
    produto,
    endereco,
    mensagem } = req.body;
  // create reusable transporter object using the default SMTP transport
  const transporter = nodemailer.createTransport({
    host: SMTP_CONFIG.host,
    port: SMTP_CONFIG.port,
    secure: true, // true for 465, false for other ports
    auth: {
      user: SMTP_CONFIG.user, // generated ethereal user
      pass: SMTP_CONFIG.pass, // generated ethereal password
    },
    tls: {
      rejectUnauthorized: false,
    }
  });


  const msg = {
    // to: `${email}`,  list of receivers 
    from: 'atavira@aditel.us',// sender address
    to: 'atavira@aditel.us', //"atavira@aditel.us" list of receivers
    replyTo: `${email}`, //" responder para 
    subject: `${assunto}`, // Subject line
    text: "Coding Day?", // plain text body
    html: `	<div>
     <p>
     ${nome},
      </p>
      <p>
     
         📧 ${email},
        <br> 
         📞 ${telef},
         <br>  
             
         🌏 ${endereco}, 
      </p> 
    
      <p>
      ${produto},
      <br>
      ${mensagem}
      </p>
    </div>`, // html body
  }
  // send mail with defined transport object
  const info = await transporter.sendMail(msg);

  console.log("Message sent: %s", info);
  console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));

  res.send('email enviada')
})
// async..await is not allowed in global scope, must use a wrapper

app.listen(port, () => console.log(`Running on port ${port}!`))