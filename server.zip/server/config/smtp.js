module.exports = {
    host: "mail.aditel.us",
    port: 465, 
    user: 'atavira@aditel.us', // your cPanel email address
    pass: 'Satfrotas@', // your cPanel email password

};

 